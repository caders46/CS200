public class main{
    public static void main(String[] args){
        FibonacciCalculator calc = new FibonacciCalculator();
        int fib11 = calc.FibonacciCalculator(11);
        System.out.println("Fib(11) is " + fib11);
    }
}